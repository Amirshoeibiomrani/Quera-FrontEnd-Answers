export default {
  //customer location
  customerLatitude: 35.7793764,
  customerLongtitude: 51.4241308,

  //vendor location
  vendorLatitude: 35.7741687,
  vendorLongtitude: 51.4184278,

  //biker location
  bikerLatitude: 35.7794331,
  bikerLongtitude: 51.4256266,

  vendorType: 'RESTAURANT',
  vendorTypeTitle: 'رستوران',
  expeditionType: 'PICKUP',
  bikerName: 'محمد محمدی',
  bikerCellphone: '+989121231234'
};
