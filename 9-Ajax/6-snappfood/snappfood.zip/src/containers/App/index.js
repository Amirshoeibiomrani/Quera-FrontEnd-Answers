import React from 'react';
import Router from './Router';

export default function App() {
  return (
    <React.Fragment>
      <Router />
    </React.Fragment>
  );
}
