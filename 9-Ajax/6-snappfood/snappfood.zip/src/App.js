import React from 'react';
import FollowOrder from './containers/FollowOrder';

function App() {
  return (
    <div className="App">
      <FollowOrder />
    </div>
  );
}

export default App;
